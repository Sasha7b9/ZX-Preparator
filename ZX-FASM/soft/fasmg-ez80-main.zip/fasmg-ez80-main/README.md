# fasmg-ez80 [![Build Status](https://travis-ci.org/jacobly0/fasmg-ez80.svg?branch=master)](https://travis-ci.org/jacobly0/fasmg-ez80)
fasmg ez80 include files

These include files are meant to be used with fasmg, which can be downloaded near the bottom of this page: http://flatassembler.net/download.php
