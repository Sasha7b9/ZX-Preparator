#ifndef LIB765CONFIG_H
#define LIB765CONFIG_H

#define PATH_MAX 256
#define HAVE_LIBDSK_H
#endif
