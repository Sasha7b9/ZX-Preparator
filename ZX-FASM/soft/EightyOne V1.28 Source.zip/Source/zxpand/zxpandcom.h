#ifndef __ZXPANDCOM_H
#define __ZXPANDCOM_H

COMFUNC(DirectoryOpen,400)
COMFUNC(DirectoryRead,200)
COMFUNC(FileOpenRead,400)
COMFUNC(FileOpenWrite,400)
COMFUNC(FileRead,100)
COMFUNC(FileWrite,140)
COMFUNC(FileClose,50)
COMFUNC(FileDelete,400)
COMFUNC(FileRename,100)
COMFUNC(ParseBuffer,10)
COMFUNC(ParseBufferPlus,10)
COMFUNC(ZXpandContinuation,10)
COMFUNC(Boot,100)
COMFUNC(FileSeek,10)
#endif
