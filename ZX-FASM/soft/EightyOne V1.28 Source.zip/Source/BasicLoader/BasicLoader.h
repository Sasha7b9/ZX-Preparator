#include <vcl.h>

extern void LoadZX80Basic(AnsiString filename);
extern void LoadZX81Basic(AnsiString filename);
extern void LoadSpectrumBasic(AnsiString filename);

